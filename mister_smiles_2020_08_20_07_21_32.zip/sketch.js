let circle = {
  x: 200,
  y: 300,
  xspeed: 3,
  yspeed: 3
}

function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(4, 20, 500);


  fill(200, 0, 0)
  circle(400, 400, 500)
  console.log(mouseX, mouseY)

  fill(255, 255, 255)
  circle(335, 340, 70)
  circle(466, 345, 70)

  fill(23, 3, 3)
  circle(335, 340, 40)
  circle(466, 347, 40)

  function draw() {
    background(220);
    display()
    bounce()
    move()
  }

  function display() {
    circle(ball.x, ball.y, 90) // callin a function

  }

  function bounce() {
    if (ball.x > width || ball.x < 0) {
      ball.xspeed = ball.xspeed * -1
    }
    if (ball.y > height || ball.y < 0) {
      ball.yspeed = ball.yspeed * -1
    }

  }

  function move() {
    ball.x = ball.x + ball.xspeed
    ball.y += ball.yspeed



  }
  fill(255, 255, 255)
  arc(397, 474, 150, 150, 0, PI);
}